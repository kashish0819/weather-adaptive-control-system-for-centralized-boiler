#include <WiFi.h>
#include <HTTPClient.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// -------------------- PIN DEFINITIONS --------------------
#define FLOW_SENSOR 4
#define ONE_WIRE_BUS 15
#define RELAY_PIN 26

// -------------------- WIFI --------------------
const char* ssid = "realme 10 Pro 5G";
const char* password = "kashish000";
const char* serverName = "http://10.37.171.247:5000/update";

// -------------------- FLOW --------------------
volatile int pulseCount = 0;
float flowRate = 0;

// -------------------- DS18B20 --------------------
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);

// -------------------- INTERRUPT --------------------
void IRAM_ATTR pulseCounter() {
  pulseCount++;
}

// -------------------- SETUP --------------------
void setup() {
  Serial.begin(115200);

  // Flow sensor
  pinMode(FLOW_SENSOR, INPUT);
  attachInterrupt(digitalPinToInterrupt(FLOW_SENSOR), pulseCounter, FALLING);

  // Relay
  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, HIGH); // OFF (active LOW)

  // Temperature sensor
  sensors.begin();

  // WiFi
  WiFi.begin(ssid, password);
  Serial.print("Connecting");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected!");
  Serial.println(WiFi.localIP());
}

// -------------------- LOOP --------------------
void loop() {

  // Measure Flow
  pulseCount = 0;
  delay(1000);
  flowRate = pulseCount / 7.5;

  // Read Temperature
  sensors.requestTemperatures();
  float waterTemp = sensors.getTempCByIndex(0);

  Serial.print("Temp: ");
  Serial.print(waterTemp);
  Serial.print("  Flow: ");
  Serial.println(flowRate);

  // Relay Control
  if (waterTemp < 50) {
    digitalWrite(RELAY_PIN, LOW);  // ON
  }
  else if (waterTemp > 60) {
    digitalWrite(RELAY_PIN, HIGH); // OFF
  }

  // Send to Flask
  if (WiFi.status() == WL_CONNECTED) {

    HTTPClient http;
    http.begin(serverName);
    http.addHeader("Content-Type", "application/json");

    String json = "{\"water_temp\":";
    json += waterTemp;
    json += ",\"flow_rate\":";
    json += flowRate;
    json += "}";

    int httpResponseCode = http.POST(json);

    Serial.print("HTTP Response: ");
    Serial.println(httpResponseCode);

    http.end();
  }

  delay(3000);
}
